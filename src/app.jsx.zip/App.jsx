
import { useMemo, useState } from "react";
import "./App.css";

const TALABAT_URL =
  "https://www.talabat.com/uae/al-yaqoot-restaurant";

const PHONE = "092774567";
const WHATSAPP = "0507792866";

const menuItems = [
  {
    id: 1,
    name: "Chicken Mandi",
    ar: "مندي دجاج",
    category: "Mandi",
    price: 28,
    image:
      "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=85",
    description: "Fragrant rice with tender mandi chicken.",
  },
  {
    id: 2,
    name: "Mutton Mandi",
    ar: "مندي لحم",
    category: "Mandi",
    price: 38,
    image:
      "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=85",
    description: "Slow-cooked mutton with aromatic rice.",
  },
  {
    id: 3,
    name: "Mutton Kabab",
    ar: "كباب لحم",
    category: "Grill",
    price: 32,
    image:
      "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?auto=format&fit=crop&w=900&q=85",
    description: "Juicy, smoky mutton kabab.",
  },
  {
    id: 4,
    name: "Chicken Kabab",
    ar: "كباب دجاج",
    category: "Grill",
    price: 26,
    image:
      "https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=900&q=85",
    description: "Char-grilled chicken with bold spices.",
  },
  {
    id: 5,
    name: "Family Special Grill",
    ar: "مشاوي عائلية",
    category: "Grill",
    price: 89,
    image:
      "https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=900&q=85",
    description: "A generous mixed-grill platter.",
  },
  {
    id: 6,
    name: "Mushroom Soup",
    ar: "شوربة الفطر",
    category: "Sides",
    price: 16,
    image:
      "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85",
    description: "Creamy mushroom soup, served warm.",
  },
  {
    id: 7,
    name: "Seafood Soup",
    ar: "شوربة المأكولات البحرية",
    category: "Sides",
    price: 22,
    image:
      "https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?auto=format&fit=crop&w=900&q=85",
    description: "A warming soup inspired by the sea.",
  },
  {
    id: 8,
    name: "Mutabbal",
    ar: "متبل",
    category: "Sides",
    price: 14,
    image:
      "https://images.unsplash.com/photo-1577906096429-f73c2c312435?auto=format&fit=crop&w=900&q=85",
    description: "Smoky aubergine dip with a creamy finish.",
  },
  {
    id: 9,
    name: "Arabic Salad",
    ar: "سلطة عربية",
    category: "Sides",
    price: 12,
    image:
      "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=900&q=85",
    description: "Fresh chopped vegetables and herbs.",
  },
  {
    id: 10,
    name: "Mutton Biriyani",
    ar: "برياني لحم",
    category: "Biriyani",
    price: 32,
    image:
      "https://images.unsplash.com/photo-1563379091339-03246963d96c?auto=format&fit=crop&w=900&q=85",
    description: "Spiced basmati rice with tender mutton.",
  },
  {
    id: 11,
    name: "Chicken Biriyani",
    ar: "برياني دجاج",
    category: "Biriyani",
    price: 25,
    image:
      "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=900&q=85",
    description: "Classic chicken biriyani with fragrant spices.",
  },
  {
    id: 12,
    name: "Butter Chicken",
    ar: "دجاج بالزبدة",
    category: "Curries",
    price: 27,
    image:
      "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=900&q=85",
    description: "Creamy tomato curry with tender chicken.",
  },
  {
    id: 13,
    name: "Paneer Butter Masala",
    ar: "بانير بالزبدة",
    category: "Curries",
    price: 23,
    image:
      "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=85",
    description: "Paneer cubes in a rich buttery masala.",
  },
  {
    id: 14,
    name: "Chicken Shawarma",
    ar: "شاورما دجاج",
    category: "Snacks",
    price: 12,
    image:
      "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=900&q=85",
    description: "Seasoned chicken wrapped with fresh toppings.",
  },
  {
    id: 15,
    name: "Beef Shawarma",
    ar: "شاورما لحم",
    category: "Snacks",
    price: 14,
    image:
      "https://images.unsplash.com/photo-1561651823-34feb02250e4?auto=format&fit=crop&w=900&q=85",
    description: "Beef shawarma with tangy sauce.",
  },
  {
    id: 16,
    name: "Loaded Fries",
    ar: "بطاطس محملة",
    category: "Snacks",
    price: 19,
    image:
      "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85",
    description: "Crispy fries loaded with delicious toppings.",
  },
  {
    id: 17,
    name: "Creamy Alfredo Pasta",
    ar: "باستا ألفريدو",
    category: "Pasta",
    price: 24,
    image:
      "https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&w=900&q=85",
    description: "Creamy pasta with herbs.",
  },
  {
    id: 18,
    name: "Spicy Arrabbiata Pasta",
    ar: "باستا أرابياتا حارة",
    category: "Pasta",
    price: 22,
    image:
      "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=85",
    description: "Pasta in a lively tomato chilli sauce.",
  },
  {
    id: 19,
    name: "Fresh Orange Juice",
    ar: "عصير برتقال",
    category: "Juices",
    price: 10,
    image:
      "https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&w=900&q=85",
    description: "Fresh citrus refreshment.",
  },
  {
    id: 20,
    name: "Mango Juice",
    ar: "عصير مانجو",
    category: "Juices",
    price: 10,
    image:
      "https://images.unsplash.com/photo-1622597467836-f3285f2131b8?auto=format&fit=crop&w=900&q=85",
    description: "Sweet, tropical mango flavour.",
  },
  {
    id: 21,
    name: "Watermelon Juice",
    ar: "عصير بطيخ",
    category: "Juices",
    price: 10,
    image:
      "https://images.unsplash.com/photo-1525385133512-2f3bdd039054?auto=format&fit=crop&w=900&q=85",
    description: "A refreshing summer favourite.",
  },
  {
    id: 22,
    name: "Avocado Juice",
    ar: "عصير أفوكادو",
    category: "Juices",
    price: 14,
    image:
      "https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=900&q=85",
    description: "Smooth and creamy avocado drink.",
  },
];

const categories = [
  "All",
  ...new Set(menuItems.map((item) => item.category)),
];

function readStorage(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
}

const money = (amount) => `AED ${amount.toFixed(2)}`;

export default function App() {
  const [language, setLanguage] = useState("en");
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState(() =>
    readStorage("yaqooth_cart", [])
  );
  const [orders, setOrders] = useState(() =>
    readStorage("yaqooth_orders", [])
  );
  const [page, setPage] = useState("home");
  const [customer, setCustomer] = useState({
    name: "",
    phone: "",
    address: "",
    notes: "",
  });
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [adminLoggedIn, setAdminLoggedIn] = useState(false);
  const [notice, setNotice] = useState("");

  const isArabic = language === "ar";
  const t = (en, ar) => (isArabic ? ar : en);

  const cartCount = cart.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const visibleItems = useMemo(() => {
    const term = search.trim().toLowerCase();

    return menuItems.filter((item) => {
      const correctCategory =
        category === "All" || item.category === category;

      const correctSearch =
        !term ||
        `${item.name} ${item.ar} ${item.category}`
          .toLowerCase()
          .includes(term);

      return correctCategory && correctSearch;
    });
  }, [category, search]);

  function saveCart(nextCart) {
    setCart(nextCart);
    localStorage.setItem("yaqooth_cart", JSON.stringify(nextCart));
  }

  function addToCart(item) {
    const found = cart.find((row) => row.id === item.id);

    const nextCart = found
      ? cart.map((row) =>
          row.id === item.id
            ? { ...row, quantity: row.quantity + 1 }
            : row
        )
      : [...cart, { ...item, quantity: 1 }];

    saveCart(nextCart);
    setNotice(`${item.name} added to cart`);

    window.setTimeout(() => setNotice(""), 2000);
  }

  function changeQuantity(id, amount) {
    const nextCart = cart
      .map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + amount }
          : item
      )
      .filter((item) => item.quantity > 0);

    saveCart(nextCart);
  }

  function placeOrder(event) {
    event.preventDefault();

    const order = {
      id: `AY-${Date.now().toString().slice(-7)}`,
      createdAt: new Date().toLocaleString(),
      customer,
      items: cart.map(({ id, name, price, quantity }) => ({
        id,
        name,
        price,
        quantity,
      })),
      total,
      status: "Received",
    };

    const nextOrders = [order, ...orders];

    setOrders(nextOrders);
    localStorage.setItem(
      "yaqooth_orders",
      JSON.stringify(nextOrders)
    );

    saveCart([]);
    setPage("success");
  }

  function loginAdmin(event) {
    event.preventDefault();

    if (adminPassword === "admin123") {
      setAdminLoggedIn(true);
      setNotice("");
    } else {
      setNotice("Incorrect password. Demo password: admin123");
    }
  }

  return (
    <div
      className={`yaqooth-app ${isArabic ? "rtl" : ""}`}
      dir={isArabic ? "rtl" : "ltr"}
    >
      <div className="top-strip">
        KALBA, FUJAIRAH · UNITED ARAB EMIRATES
        <span>✦</span>
        A TASTE WORTH GATHERING FOR
      </div>

      <header className="site-header">
        <a className="brand" href="#home" onClick={() => setPage("home")}>
          <img
            src="/logo.jpg"
            alt="Al Yaqooth Restaurant"
            onError={(event) => {
              event.currentTarget.style.display = "none";
            }}
          />
          <span>
            <strong>AL YAQOOTH</strong>
            <small>RESTAURANT</small>
          </span>
        </a>

        <nav className="desktop-nav">
          <a href="#home" onClick={() => setPage("home")}>Home</a>
          <a href="#story">Our Story</a>
          <a href="#menu">Menu</a>
          <a href="#visit">Visit Us</a>
        </nav>

        <div className="header-actions">
          <button
            className="language-toggle"
            onClick={() => setLanguage(isArabic ? "en" : "ar")}
          >
            {isArabic ? "EN" : "عربي"}
          </button>

          <button
            className="cart-trigger"
            onClick={() =>
              setPage(page === "cart" ? "home" : "cart")
            }
          >
            ♧ Cart <b>{cartCount}</b>
          </button>
        </div>
      </header>

      {page === "home" && (
        <main>
          <section className="hero-section" id="home">
            <div className="hero-content">
              <p className="eyebrow">
                <span /> TRADITION · FLAVOUR · TOGETHERNESS
              </p>

              <h1>
                Gather around
                <br />
                <em>great flavour.</em>
              </h1>

              <p className="hero-description">
                From fragrant mandi to flame-kissed grills,
                discover generous meals made for sharing and
                memories made around the table.
              </p>

              <div className="hero-buttons">
                <a className="btn btn-gold" href="#menu">
                  Explore the menu ↗
                </a>
                <a
                  className="text-link"
                  href={TALABAT_URL}
                  target="_blank"
                  rel="noreferrer"
                >
                  Order on Talabat ↗
                </a>
              </div>

              <div className="hero-stats">
                <div>
                  <strong>22</strong>
                  <span>MENU FAVOURITES</span>
                </div>
                <i />
                <div>
                  <strong>Made</strong>
                  <span>WITH CARE</span>
                </div>
                <i />
                <div>
                  <strong>UAE</strong>
                  <span>LOCAL HOSPITALITY</span>
                </div>
              </div>
            </div>

            <div className="hero-art">
              <div className="hero-image-main">
                <img src={menuItems[0].image} alt="Chicken Mandi" />
              </div>

              <div className="hero-image-small">
                <img
                  src={menuItems[4].image}
                  alt="Family Special Grill"
                />
              </div>

              <div className="hero-stamp">
                <span>AL</span>
                <strong>YAQOOTH</strong>
                <small>GOOD FOOD · GOOD COMPANY</small>
              </div>

              <div className="hero-ring" />
            </div>

            <div className="hero-bottom-note">
              ✦ YOUR TABLE IS WAITING
            </div>
          </section>

          <section className="story-section section-wrap" id="story">
            <div className="story-photo">
              <img src={menuItems[1].image} alt="Mutton Mandi" />
              <div className="photo-caption">
                <span>01 /</span> Made to be shared
              </div>
            </div>

            <div className="story-copy">
              <p className="eyebrow">
                <span /> A PLACE AT OUR TABLE
              </p>

              <h2>
                Good food brings
                <br />
                <em>people closer.</em>
              </h2>

              <p>
                At Al Yaqooth, every meal is an invitation to
                slow down, share generously and enjoy familiar
                flavours. From comforting rice dishes to
                sizzling grills and refreshing juices, there
                is something for every gathering.
              </p>

              <a href="#menu" className="underlined-link">
                Find your favourite ↗
              </a>
            </div>
          </section>

          <section className="menu-section" id="menu">
            <div className="section-wrap">
              <div className="menu-heading">
                <div>
                  <p className="eyebrow">
                    <span /> FROM OUR KITCHEN
                  </p>
                  <h2>
                    Made for your <em>cravings.</em>
                  </h2>
                </div>

                <p className="menu-intro">
                  Comforting classics, bold grills and fresh
                  sips — choose what calls to you.
                </p>
              </div>

              <div className="menu-tools">
                <div className="category-list">
                  {categories.map((item) => (
                    <button
                      key={item}
                      className={
                        category === item
                          ? "category-chip active"
                          : "category-chip"
                      }
                      onClick={() => setCategory(item)}
                    >
                      {item === "All" ? "All dishes" : item}
                    </button>
                  ))}
                </div>

                <input
                  className="menu-search"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search the menu..."
                  aria-label="Search menu"
                />
              </div>

              <div className="menu-grid">
                {visibleItems.map((item, index) => (
                  <article
                    className="food-card"
                    key={item.id}
                    style={{ "--delay": `${(index % 4) * 70}ms` }}
                  >
                    <div className="food-image-wrap">
                      <img src={item.image} alt={item.name} loading="lazy" />
                      <span className="food-number">
                        {String(item.id).padStart(2, "0")}
                      </span>
                      <button
                        className="quick-add"
                        onClick={() => addToCart(item)}
                        aria-label={`Add ${item.name} to cart`}
                      >
                        +
                      </button>
                    </div>

                    <div className="food-info">
                      <div className="food-title-row">
                        <h3>{isArabic ? item.ar : item.name}</h3>
                        <strong>{money(item.price)}</strong>
                      </div>

                      <p>
                        {isArabic ? item.ar : item.description}
                      </p>

                      <div className="food-card-bottom">
                        <span>{item.category.toUpperCase()}</span>
                        <button onClick={() => addToCart(item)}>
                          ADD TO ORDER ↗
                        </button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>

              {visibleItems.length === 0 && (
                <p className="empty-state">
                  No dishes found. Try another search.
                </p>
              )}

              <p className="menu-disclaimer">
                Menu prices are sample prices in AED. Confirm
                availability and final prices with the restaurant.
              </p>
            </div>
          </section>

          <section className="order-banner">
            <div>
              <p className="eyebrow">
                <span /> A FEW TAPS AWAY
              </p>
              <h2>Your favourites, delivered.</h2>
              <p>
                Order online through Talabat, or build your
                cart here and enquire through WhatsApp.
              </p>
            </div>

            <a
              href={TALABAT_URL}
              target="_blank"
              rel="noreferrer"
              className="btn btn-gold"
            >
              Order on Talabat ↗
            </a>
          </section>

          <section className="visit-section section-wrap" id="visit">
            <div>
              <p className="eyebrow">
                <span /> COME SAY HELLO
              </p>
              <h2>
                We'll save you
                <br />
                <em>a seat.</em>
              </h2>
            </div>

            <div className="visit-details">
              <div>
                <span className="detail-icon">⌖</span>
                <p>
                  <small>FIND US</small>
                  <strong>Al Yaqooth Restaurant</strong>
                  <span>Kalba, Fujairah, UAE</span>
                </p>
              </div>

              <div>
                <span className="detail-icon">☎</span>
                <p>
                  <small>CALL THE RESTAURANT</small>
                  <a href={`tel:${PHONE}`}>{PHONE}</a>
                  <span>For questions and availability</span>
                </p>
              </div>

              <div>
                <span className="detail-icon">◉</span>
                <p>
                  <small>WHATSAPP</small>
                  <a
                    href={`https://wa.me/971${WHATSAPP.replace(/^0/, "")}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {WHATSAPP}
                  </a>
                  <span>Send us your order enquiry</span>
                </p>
              </div>
            </div>
          </section>
        </main>
      )}

      {page === "cart" && (
        <main className="subpage section-wrap">
          <button className="back-link" onClick={() => setPage("home")}>
            ← Back to menu
          </button>

          <p className="eyebrow">
            <span /> YOUR SELECTION
          </p>

          <h1 className="subpage-title">Your cart.</h1>

          {cart.length === 0 ? (
            <div className="empty-cart">
              <h2>Your table is waiting.</h2>
              <p>Add a few favourites from the menu to get started.</p>
              <button
                className="btn btn-gold"
                onClick={() => setPage("home")}
              >
                Explore menu
              </button>
            </div>
          ) : (
            <div className="checkout-layout">
              <div className="cart-list">
                {cart.map((item) => (
                  <div className="cart-row" key={item.id}>
                    <img src={item.image} alt={item.name} />

                    <div className="cart-item-copy">
                      <h3>{item.name}</h3>
                      <span>{money(item.price)} each</span>

                      <div className="quantity-control">
                        <button onClick={() => changeQuantity(item.id, -1)}>
                          -
                        </button>
                        <strong>{item.quantity}</strong>
                        <button onClick={() => changeQuantity(item.id, 1)}>
                          +
                        </button>
                      </div>
                    </div>

                    <strong className="line-total">
                      {money(item.price * item.quantity)}
                    </strong>
                  </div>
                ))}
              </div>

              <form className="checkout-form" onSubmit={placeOrder}>
                <h2>Order details</h2>

                <label>
                  Full name
                  <input
                    required
                    value={customer.name}
                    onChange={(event) =>
                      setCustomer({ ...customer, name: event.target.value })
                    }
                  />
                </label>

                <label>
                  Phone number
                  <input
                    required
                    type="tel"
                    value={customer.phone}
                    onChange={(event) =>
                      setCustomer({ ...customer, phone: event.target.value })
                    }
                  />
                </label>

                <label>
                  Delivery address / pickup details
                  <textarea
                    required
                    rows="3"
                    value={customer.address}
                    onChange={(event) =>
                      setCustomer({
                        ...customer,
                        address: event.target.value,
                      })
                    }
                  />
                </label>

                <label>
                  Notes (optional)
                  <textarea
                    rows="2"
                    value={customer.notes}
                    onChange={(event) =>
                      setCustomer({ ...customer, notes: event.target.value })
                    }
                  />
                </label>

                <div className="total-row">
                  <span>Subtotal</span>
                  <strong>{money(total)}</strong>
                </div>

                <p className="checkout-note">
                  Demo only: this order is saved in this browser.
                  It does not process payments or automatically
                  send the order to the restaurant.
                </p>

                <button className="btn btn-gold full-width" type="submit">
                  Place demo order ↗
                </button>

                <a
                  className="whatsapp-order"
                  href={`https://wa.me/971${WHATSAPP.replace(/^0/, "")}?text=${encodeURIComponent(
                    `Hello Al Yaqooth! I would like to enquire about: ${cart
                      .map((item) => `${item.quantity} x ${item.name}`)
                      .join(", ")}. Total: ${money(total)}`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Enquire via WhatsApp instead
                </a>
              </form>
            </div>
          )}
        </main>
      )}

      {page === "success" && (
        <main className="subpage success-page">
          <div className="success-card">
            <div className="success-mark">✓</div>

            <p className="eyebrow">
              <span /> ORDER SAVED
            </p>

            <h1>
              Thank you for choosing
              <br />
              <em>Al Yaqooth.</em>
            </h1>

            <p>
              Your demo order has been saved in this browser.
              Please contact the restaurant to confirm the actual order.
            </p>

            <a
              className="btn btn-gold"
              href={`https://wa.me/971${WHATSAPP.replace(/^0/, "")}`}
              target="_blank"
              rel="noreferrer"
            >
              Contact us on WhatsApp ↗
            </a>

            <button className="text-link" onClick={() => setPage("home")}>
              Return to home
            </button>
          </div>
        </main>
      )}

      {notice && !adminOpen && <div className="toast">{notice}</div>}

      {adminOpen && (
        <div className="admin-overlay">
          <div className="admin-modal">
            <button
              className="modal-close"
              onClick={() => {
                setAdminOpen(false);
                setAdminLoggedIn(false);
              }}
              aria-label="Close admin"
            >
              ×
            </button>

            {!adminLoggedIn ? (
              <>
                <p className="eyebrow">
                  <span /> ADMIN ACCESS
                </p>

                <h2>Restaurant dashboard</h2>

                <p className="admin-warning">
                  Demo only. This password is visible in frontend code
                  and is not secure for a real business.
                </p>

                <form onSubmit={loginAdmin}>
                  <label>
                    Demo password
                    <input
                      type="password"
                      value={adminPassword}
                      onChange={(event) =>
                        setAdminPassword(event.target.value)
                      }
                    />
                  </label>

                  {notice && <p className="notice">{notice}</p>}

                  <button className="btn btn-gold full-width">
                    Open dashboard
                  </button>
                </form>
              </>
            ) : (
              <>
                <p className="eyebrow">
                  <span /> ADMIN OVERVIEW
                </p>

                <h2>Order dashboard</h2>

                <div className="admin-metrics">
                  <div>
                    <small>ORDERS SAVED</small>
                    <strong>{orders.length}</strong>
                  </div>
                  <div>
                    <small>MENU ITEMS</small>
                    <strong>{menuItems.length}</strong>
                  </div>
                  <div>
                    <small>ORDER VALUE</small>
                    <strong>
                      {money(orders.reduce((sum, order) => sum + order.total, 0))}
                    </strong>
                  </div>
                </div>

                {orders.length ? (
                  <div className="admin-orders">
                    {orders.map((order) => (
                      <article key={order.id}>
                        <div>
                          <strong>{order.id}</strong>
                          <span>{order.createdAt}</span>
                        </div>
                        <p>
                          {order.customer.name} · {order.customer.phone}
                        </p>
                        <p>
                          {order.items
                            .map((item) => `${item.quantity} × ${item.name}`)
                            .join(", ")}
                        </p>
                        <strong>{money(order.total)}</strong>
                      </article>
                    ))}
                  </div>
                ) : (
                  <p>No demo orders saved in this browser yet.</p>
                )}
              </>
            )}
          </div>
        </div>
      )}

      <footer className="site-footer">
        <div className="footer-top">
          <a className="brand footer-brand" href="#home">
            <span>
              <strong>AL YAQOOTH</strong>
              <small>RESTAURANT</small>
            </span>
          </a>

          <p>Good food. Generous hearts. A place for everyone.</p>

          <a
            className="footer-order"
            href={TALABAT_URL}
            target="_blank"
            rel="noreferrer"
          >
            ORDER ON TALABAT ↗
          </a>
        </div>

        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Al Yaqooth Restaurant</span>
          <span>Kalba · Fujairah · UAE</span>
          <button
            onClick={() => {
              setAdminOpen(true);
              setNotice("");
            }}
          >
            Admin demo
          </button>
        </div>
      </footer>
    </div>
  );
}

